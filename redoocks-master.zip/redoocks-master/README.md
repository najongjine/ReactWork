# Redoocks

Redux Clone using React Hooks (useContext and useReducer)